package org.kosta.juicetaproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuicetaProjectApplicationTests {

	@Test
	void contextLoads() {
	}
}
