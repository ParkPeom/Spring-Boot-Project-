package org.kosta.juicetaproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuicetaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuicetaProjectApplication.class, args);
	}

}
